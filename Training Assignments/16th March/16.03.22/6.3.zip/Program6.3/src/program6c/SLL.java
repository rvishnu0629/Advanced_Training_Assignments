package program6c;

public class SLL {
	public static void main(String[] args) {
        LinkedList<Employee> linkedList = new LinkedList<Employee>(); // creation of Linked List
        
        linkedList.insertFirst(new Employee("11", "Abi","a1"));
        linkedList.insertFirst(new Employee("12", "Kamesh","b1"));
        linkedList.insertFirst(new Employee("13", "Pradeep","c1"));
        linkedList.insertFirst(new Employee("14", "Arul","d1"));
        linkedList.insertFirst(new Employee("15", "Srini","e1"));

        linkedList.displayLinkedList();
  }
}
